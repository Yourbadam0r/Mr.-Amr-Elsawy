# Mr Amr Elsawy — Vercel WebView APK

This Android wrapper does NOT modify the Vercel project or its file structure.
It simply opens the existing Vercel URL inside a native Android WebView.

Website URL:
https://3mrelsawi-gn2h-1br3nkk0z-yourbadam0rs-projects.vercel.app/

Any HTML/CSS/JS/content update deployed to Vercel will appear in the app when it reloads.

Build:
1. Upload this project to a GitHub repository.
2. Open Actions.
3. Run "Build APK".
4. Download the artifact "Mr-Amr-Elsawy-APK".
